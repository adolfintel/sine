#!/bin/bash
p7zip
if [ $? -eq 127 ]; then
	echo "p7zip is required. Run apt-get install p7zip"
	exit 1
fi
wget http://downloads.fdossena.com/geth.php?r=sine-pcbin -O sine.7z
if [ $? -ne 0 ]; then
	echo "Download failed"
	exit 2
fi
p7zip -d sine.7z
rm -f *.txt
rm -f *.md
chmod 755 *.jar
chmod 755 lib
chmod 755 lib/*.jar
chmod 644 editor_manual
chmod 644 editor_manual/*
mv *.jar sine/usr/share/sine/
mv lib sine/usr/share/sine/
mv editor_manual sine/usr/share/sine/
dpkg -b sine/ sine.deb
